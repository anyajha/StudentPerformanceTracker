﻿namespace StudentPerformanceAPI.Models
{
    public class Term
    {
        public int TermId { get; set; }
        public string Name { get; set; }
    }
}
